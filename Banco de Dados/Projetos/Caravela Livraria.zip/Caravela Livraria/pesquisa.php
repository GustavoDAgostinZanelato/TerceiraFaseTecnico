<?php
//conectar com bando dados
$conectar = mysql_connect('localhost','root','');
$banco    = mysql_select_db('livraria');
?>

<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Home </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>


<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo.png" width="230" height="130"></td>
    <td width=20%> </td>
    <td><center><a href="login.php"> <img src="Imagens/Login.png" width="40" height="40"> </a></center></td>
    </table>
</header>

<?php
if (isset($_POST['pesquisar']))
    {

    $categoria  = (empty($_POST['categoria']))?'null':$_POST['categoria'];
    $classificacao  = (empty($_POST['classificacao']))?'null':$_POST['classificacao'];

// -------------------------------------------------------------------------------------- 

    if (($categoria == 'null') and ($classificacao == 'null'))
    {
        $sql_livraria       = "SELECT * FROM livro";
        $seleciona_livraria = mysql_query($sql_livraria);
    }
}

if($seleciona_livraria == 0)
                    {
                    echo '<h3>Desculpe, mas sua busca nao retornou resultados</h3>';
                    }
                    else
                    {
                    echo "<br><center><h1>Resultado da pesquisa</h1></center>"."<br>";
                    echo "<ul>";
                            while($resultado = mysql_fetch_array($seleciona_livraria))
                            {
                            echo "<tr><td>".utf8_encode($resultado['codigo'])."</td><br>
                                    <td>".utf8_encode($resultado['titulo'])."</td><br>
                                    <td>".utf8_encode($resultado['codcategoria'])."</td><br>
                                    <td>".utf8_encode($resultado['codclassificacao'])."</td><br>
                                    <td>".utf8_encode($resultado['ano'])."</td><br>
                                    <td>".utf8_encode($resultado['edicao'])."</td><br>
                                    <td>".utf8_encode($resultado['codautor'])."</td><br>
                                    <td>".utf8_encode($resultado['editora'])."</td><br>
                                    <td>".utf8_encode($resultado['paginas'])."</td><br>
                                    <td>".utf8_encode($resultado['valor'])."</td><br>
                                    <td>".utf8_encode($resultado['fotocapa'])."</td></tr>";
                            }
                    }
?>