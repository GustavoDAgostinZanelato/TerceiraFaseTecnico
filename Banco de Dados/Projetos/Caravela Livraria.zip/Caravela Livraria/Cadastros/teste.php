<?php
// Conexão com o banco de dados usando MySQLi
$mysqli = new mysqli('localhost', 'root', '', 'livraria');

// Verificação de erros na conexão
if ($mysqli->connect_errno) {
    echo "Falha na conexão com o MySQL: " . $mysqli->connect_error;
    exit();
}

// Configurar o charset para UTF-8
$mysqli->set_charset("utf8");

// Verificar se o formulário de adicionar foi submetido
if (isset($_POST['gravar'])) {
    // Obter valores do formulário
    $codigo = $_POST['codigo'];
    $titulo = $_POST['titulo'];
    $codcategoria = $_POST['codcategoria'];
    $codclassificacao = $_POST['codclassificacao'];
    $ano = $_POST['ano'];
    $edicao = $_POST['edicao'];
    $codautor = $_POST['codautor'];
    $editora = $_POST['editora'];
    $paginas = $_POST['paginas'];
    $valor = $_POST['valor'];

    // Tratamento de upload de arquivo
    $fotocapa = $_FILES['fotocapa']['name'];
    $diretorio = "Imagens/";
    move_uploaded_file($_FILES['fotocapa']['tmp_name'], $diretorio . $fotocapa);

    // Inserir no banco de dados
    $sql = "INSERT INTO livro (codigo, titulo, codcategoria, codclassificacao, ano, edicao, codautor, editora, paginas, valor, fotocapa) 
            VALUES ('$codigo', '$titulo', '$codcategoria', '$codclassificacao', '$ano', '$edicao', '$codautor', '$editora', '$paginas', '$valor', '$fotocapa')";
    $result = $mysqli->query($sql);

    if ($result) {
        echo '<script>alert("Adicionado com Sucesso!");</script>';
        echo '<script>window.location.href="cad_livros.php";</script>';
    } else {
        echo "Erro ao adicionar registro: " . $mysqli->error;
    }
}

// Verificar se o formulário de alterar foi submetido
if (isset($_POST['alterar'])) {
    // Obter valores do formulário
    $codigo = $_POST['codigo'];
    $titulo = $_POST['titulo'];
    $codcategoria = $_POST['codcategoria'];
    $codclassificacao = $_POST['codclassificacao'];
    $ano = $_POST['ano'];
    $edicao = $_POST['edicao'];
    $codautor = $_POST['codautor'];
    $editora = $_POST['editora'];
    $paginas = $_POST['paginas'];
    $valor = $_POST['valor'];

    // Atualizar registro no banco de dados
    $sql = "UPDATE livro 
            SET titulo = '$titulo', codcategoria = '$codcategoria', codclassificacao = '$codclassificacao', 
                ano = '$ano', edicao = '$edicao', codautor = '$codautor', editora = '$editora', 
                paginas = '$paginas', valor = '$valor'
            WHERE codigo = '$codigo'";
    $result = $mysqli->query($sql);

    if ($result) {
        echo '<script>alert("Alterado com Sucesso!");</script>';
        echo '<script>window.location.href="cad_livros.php";</script>';
    } else {
        echo "Erro ao alterar registro: " . $mysqli->error;
    }
}

// Verificar se o formulário de excluir foi submetido
if (isset($_POST['excluir'])) {
    // Obter o código do livro a ser excluído
    $codigo = $_POST['codigo'];

    // Excluir registro do banco de dados
    $sql = "DELETE FROM livro WHERE codigo = '$codigo'";
    $result = $mysqli->query($sql);

    if ($result) {
        echo '<script>alert("Excluído com Sucesso!");</script>';
        echo '<script>window.location.href="cad_livros.php";</script>';
    } else {
        echo "Erro ao excluir registro: " . $mysqli->error;
    }
}

// Fechar a conexão com o banco de dados
$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Pesquisa Livros</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<script>
        /*document.getElementById('codigo').value vira simplesmente $("#codigo").val() ;-)*/
        function obterDadosModal(valor) {
            var retorno = valor.split("*");
            document.getElementById('codigo').value           = retorno[0];
            document.getElementById('titulo').value           = retorno[1];
            document.getElementById('codcategoria').value     = retorno[2];
            document.getElementById('codclassificacao').value = retorno[3];
            document.getElementById('ano').value              = retorno[4];
            document.getElementById('edicao').value           = retorno[5];
            document.getElementById('codautor').value         = retorno[6];
            document.getElementById('editora').value          = retorno[7];
            document.getElementById('paginas').value          = retorno[8];
            document.getElementById('valor').value            = retorno[9];
            document.getElementById('fotocapa').value         = retorno[10];
        }
    </script>

    <!--Modal Cadastrar-->
    <div class="modal fade" id="myModalCadastrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Adicionar um registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET" enctype="multipart/form-data">
                        <input type="text" id="codigo" name="codigo" class="span3" value="" required placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="file" id="fotocapa" name="fotocapa" class="span3" value="" required placeholder="Fotocapa" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" id="gravar" name="gravar" value="gravar" style="height: 35px">Cadastrar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>


    <!--Modal Alterar-->
    <div class="modal fade" id="myModalAlterar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Alterar de Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET" enctype="multipart/form-data">
                        <input type="text" id="codigo" name="codigo" class="span3" value=""placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="file" id="fotocapa" name="fotocapa" class="span3" value="" required placeholder="Fotocapa" style=" margin-bottom: -2px; height: 25px;"><br><br>
            
                        <button type="submit" class="btn btn-success btn-large" name="alterar" id="alterar" value="alterar" style="height: 35px">Alterar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    

     <!--Modal Excluir-->
    <div class="modal fade" id="myModalExcluir" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" enctype="multipart/form-data">
        <div class="modal-dialog" role="document">

            <div class="modal-content">
                <div class="modal-header">
                    <h1>Excluir um Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET">
                        <input id="codigo" type="text" name="codigo" value="" required placeholder="Código"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px; "><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" name="excluir" id="excluir" value="excluir" style="height: 35px">Excluir</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <h2> Lista de Livros </h2><br>
            <form action="cad_livros.php" method="GET">
                <input type="text" name="nome" id="nome" placeholder="Nome" class="span4" style="margin-bottom: -2px; height: 25px;" enctype="multipart/form-data">
                <button type="submit" name="pesquisar" id="pesquisar" class="btn btn-large" style="height: 35px;">Pesquisar</button>
                <a href="#myModalCadastrar">
                <button type="button" name="cadastrar" id="cadastrar" class="btn btn-primary" data-toggle="modal" data-target="#myModalCadastrar" data-whatever="<?php echo $dados['codigo']; ?>">Cadastrar</button></a>
            </form>
            <table border="1px" bordercolor="gray" class="table table-stripped">
                <tr>
                    <td><b>Codigo</b></td>
                    <td><b>Titulo</b></td>
                    <td><b>Cod Categoria</b></td>
                    <td><b>Cod Classificacao</b></td>
                    <td><b>Ano</b></td>
                    <td><b>Edicao</b></td>
                    <td><b>Cod Autor</b></td>
                    <td><b>Editora</b></td>
                    <td><b>Paginas</b></td>
                    <td><b>Valor</b></td>
                    <td><b>Foto Capa</b></td>
                    <td><b>Operacao</b></td>
                </tr>
</body>
</html>
