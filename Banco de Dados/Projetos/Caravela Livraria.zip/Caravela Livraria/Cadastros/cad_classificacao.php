<?php
$conectar = mysql_connect('localhost','root','');
$db       = mysql_select_db('livraria');
?>


<html>
<head>
    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
    <title> Pesquisa Classificação </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>

    <script>
        /*document.getElementById('codigo').value vira simplesmente $("#codigo").val() ;-)*/
        function obterDadosModal(valor) {
            var retorno = valor.split("*");
            document.getElementById('codigo').value = retorno[0];
            document.getElementById('nome').value   = retorno[1];
        }
    </script>

    <!--Modal Cadastrar-->
    <div class="modal fade" id="myModalCadastrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Adicionar um registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_classificacao.php" method="GET">
                        <input type="text" id="codigo" name="codigo" class="span3" value="" required placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="nome" name="nome" class="span3" value="" required placeholder="Nome" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" id="gravar" name="gravar" value="gravar" style="height: 35px">Cadastrar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>


    <!--Modal Alterar-->
    <div class="modal fade" id="myModalAlterar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Alterar de Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_classificacao.php" method="GET">
                        <input type="text" id="codigo" name="codigo" class="span3" value=""placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="nome" name="nome" class="span3" value="" required placeholder="Nome" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" name="alterar" id="alterar" value="alterar" style="height: 35px">Alterar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    

     <!--Modal Excluir-->
    <div class="modal fade" id="myModalExcluir" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">

            <div class="modal-content">
                <div class="modal-header">
                    <h1>Excluir um Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_classificacao.php" method="GET">
                        Codigo <input id="codigo" type="text" name="codigo" value="" required><br><br>
                        Nome   <input id="nome" type="text" name="nome" class="span3" required value="" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" name="excluir" id="excluir" value="excluir" style="height: 35px">Excluir</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <h2> Lista de Classificações</h2><br>
            <form action="cad_classificacao.php" method="GET">
                <input type="text" name="nome" id="nome" placeholder="Nome" class="span4" style="margin-bottom: -2px; height: 25px;">
                <button type="submit" name="pesquisar" id="pesquisar" class="btn btn-large" style="height: 35px;">Pesquisar</button>
                <a href="#myModalCadastrar">
                <button type="button" name="cadastrar" id="cadastrar" class="btn btn-primary" data-toggle="modal" data-target="#myModalCadastrar" data-whatever="<?php echo $dados['codigo']; ?>">Cadastrar</button></a>
            </form>
            <table border="1px" bordercolor="gray" class="table table-stripped">
                <tr>
                    <td><b>Codigo</b></td>
                    <td><b>Nome</b></td>
                    <td><b>Operacao</b></td>
                </tr>
                <?php
           
                if (isset($_GET['gravar'])) {

                    $codigo = $_GET['codigo'];
                    $nome   = $_GET['nome'];
                    $sql       = "insert into classificacao (codigo,nome) values ('$codigo','$nome')";
                    $resultado = mysql_query($sql);
                    
                    ?>
                    <script>
                    alert('Adicionado com Sucesso!');
                    <?php
                        echo "location.href='cad_classificacao.php'";
                    ?>
                    </script>
                <?php
     
                }

                if (isset($_GET['alterar'])) {
                
                    $codigo= $_GET['codigo'];
                    $nome  = $_GET['nome'];
                    
                    $sql      = "update classificacao set nome = '$nome'
                                 where codigo = '$codigo'";
                    $resultado = mysql_query($sql);
                    
                    ?>
                    <script>
                    alert('Alterado com Sucesso!');
                    <?php
                        echo "location.href='cad_classificacao.php'";
                    ?>
                    </script>
                <?php
                   
                }

                if (isset($_GET['excluir'])) {
                
                    $codigo= $_GET['codigo'];
                    $nome  = $_GET['nome'];
                    
                    $sql      = "delete from classificacao where codigo = '$codigo'";
                    $resultado = mysql_query($sql);
                    
                    ?>
                    <script>
                    alert('Excluido com Sucesso!');
                    <?php
                        echo "location.href='cad_classificacao.php'";
                    ?>
                    </script>
                <?php
                }


                if (isset($_GET['pesquisar']))
                {
              	    $consulta = "select * from classificacao";

                   	if ($_GET['nome'] != '')
                   	{
						$consulta = $consulta." where nome like '%".$_GET['nome']."%'";
                    }
					
					$resultado = mysql_query($consulta);
					echo $resultado;

					while ($dados = mysql_fetch_array($resultado))
                    {
						$strdados = $dados['codigo']."*".$dados['nome'];
				    ?>
                    <tr>
                        <td><?php echo $dados['codigo']; ?></td>
                        <td><?php echo $dados['nome']; ?></td>
                        <td>
						<a href="#myModalExcluir">
                        <button type='button' id='excluir' name='excluir' class='btn btn-danger' data-toggle='modal' data-target='#myModalExcluir'>Excluir</button>
                        </a>

                       <a href="#myModalAlterar">
                       <button type='button' id='alterar' name='alterar' class='btn btn-primary' data-toggle='modal' data-target='#myModalAlterar'>Alterar</button>
                       </a>
                        </td>
                    </tr>
                <?php
                }
                }
                ?>
            </table>
        </div>
    </div>

    <!-- Biblioteca requerida -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>