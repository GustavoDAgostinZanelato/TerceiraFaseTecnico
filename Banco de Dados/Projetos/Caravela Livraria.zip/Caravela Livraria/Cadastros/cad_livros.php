<?php
$conectar = mysql_connect('localhost','root','');
$db       = mysql_select_db('livraria');
?>


<html>
<head>
    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
    <title> Pesquisa Livros </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>


    <script>
        /*document.getElementById('codigo').value vira simplesmente $("#codigo").val() ;-)*/
        function obterDadosModal(valor) {
            var retorno = valor.split("*");
            document.getElementById('codigo').value = retorno[0];
            document.getElementById('titulo').value           = retorno[1];
            document.getElementById('codcategoria').value     = retorno[2];
            document.getElementById('codclassificacao').value = retorno[3];
            document.getElementById('ano').value              = retorno[4];
            document.getElementById('edicao').value           = retorno[5];
            document.getElementById('codautor').value         = retorno[6];
            document.getElementById('editora').value          = retorno[7];
            document.getElementById('paginas').value          = retorno[8];
            document.getElementById('valor').value            = retorno[9];
            document.getElementById('fotocapa').value         = retorno[10];
        }
    </script>

    <!--Modal Cadastrar-->
    <div class="modal fade" id="myModalCadastrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Adicionar um registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET" enctype="multipart/form-data">
                        <input type="text" id="codigo" name="codigo" class="span3" value="" required placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="file" id="fotocapa" name="fotocapa" class="span3" value="" required placeholder="Fotocapa" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" id="gravar" name="gravar" value="gravar" style="height: 35px">Cadastrar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>


    <!--Modal Alterar-->
    <div class="modal fade" id="myModalAlterar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Alterar de Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET" enctype="multipart/form-data">
                        <input type="text" id="codigo" name="codigo" class="span3" value=""placeholder="Codigo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="file" id="fotocapa" name="fotocapa" class="span3" value="" required placeholder="Fotocapa" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" name="alterar" id="alterar" value="alterar" style="height: 35px">Alterar</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    

     <!--Modal Excluir-->
    <div class="modal fade" id="myModalExcluir" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" enctype="multipart/form-data">
        <div class="modal-dialog" role="document">

            <div class="modal-content">
                <div class="modal-header">
                    <h1>Excluir um Registro</h1>
                </div>
                <div class="modal-body">
                    <form class="form-group well" action="cad_livros.php" method="GET">
                        <input id="codigo" type="text" name="codigo" value="" required placeholder="Código"><br><br>
                        <input type="text" id="titulo" name="titulo" class="span3" value="" required placeholder="Titulo" style=" margin-bottom: -2px; height: 25px; "><br><br>
                        <input type="text" id="codcategoria" name="codcategoria" class="span3" value="" required placeholder="Codcategoria" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codclassificacao" name="codclassificacao" class="span3" value="" required placeholder="Codclassificacao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="ano" name="ano" class="span3" value="" required placeholder="Ano" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="edicao" name="edicao" class="span3" value="" required placeholder="Edicao" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="codautor" name="codautor" class="span3" value="" required placeholder="Codautor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="editora" name="editora" class="span3" value="" required placeholder="Editora" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="paginas" name="paginas" class="span3" value="" required placeholder="Paginas" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <input type="text" id="valor" name="valor" class="span3" value="" required placeholder="Valor" style=" margin-bottom: -2px; height: 25px;"><br><br>
                        <button type="submit" class="btn btn-success btn-large" name="excluir" id="excluir" value="excluir" style="height: 35px">Excluir</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <h2> Lista de Livros </h2><br>
            <form action="cad_livros.php" method="GET">
                <input type="text" name="nome" id="nome" placeholder="Nome" class="span4" style="margin-bottom: -2px; height: 25px;" enctype="multipart/form-data">
                <button type="submit" name="pesquisar" id="pesquisar" class="btn btn-large" style="height: 35px;">Pesquisar</button>
                <a href="#myModalCadastrar">
                <button type="button" name="gravar" id="gravar" class="btn btn-primary" data-toggle="modal" data-target="#myModalCadastrar" data-whatever="<?php echo $dados['codigo']; ?>">Cadastrar</button></a>
            </form>
            <table border="1px" bordercolor="gray" class="table table-stripped">
                <tr>
                    <td><b>Codigo</b></td>
                    <td><b>Titulo</b></td>
                    <td><b>Cod Categoria</b></td>
                    <td><b>Cod Classificacao</b></td>
                    <td><b>Ano</b></td>
                    <td><b>Edicao</b></td>
                    <td><b>Cod Autor</b></td>
                    <td><b>Editora</b></td>
                    <td><b>Paginas</b></td>
                    <td><b>Valor</b></td>
                    <td><b>Foto Capa</b></td>
                    <td><b>Operacao</b></td>
                </tr>
                <?php
           
                if (isset($_GET['gravar'])) {

                    $codigo           = $_GET['codigo'];
                    $titulo           = $_GET['titulo'];
                    $codcategoria     = $_GET['codcategoria'];
                    $codclassificacao = $_GET['codclassificacao'];
                    $ano              = $_GET['ano'];
                    $edicao           = $_GET['edicao'];
                    $codautor         = $_GET['codautor'];
                    $editora          = $_GET['editora'];
                    $paginas          = $_GET['paginas'];
                    $valor            = $_GET['valor'];
                    // incluir arquivos fotos (endereço da pasta no computador)
                    $fotocapa         = $_FILES['fotocapa'];
                            
                    //criar pasta computador
                    $diretorio = "Imagens/";
                        
                    //Esta função  usada para converter caracteres em string
                    $extensao = strtolower(substr($_FILES['fotocapa']['name'], -4));

                    //faz md5 para nao ter nomes repetidos nas fotos
                    $novo_nome = md5(time()).$extensao;

                    //mover arquivo da foto para a pasta FOTOS no computador
                    move_uploaded_file($_FILES['fotocapa']['tmp_name'], $diretorio.$novo_nome);

                            $add = mysql_query("insert into livro (codigo, titulo, codcategoria, codclassificacao, ano, edicao, codautor, editora, paginas, valor, fotocapa) values('$codigo', '$titulo', '$codcategoria', '$codclassificacao', '$ano', '$edicao', '$codautor', '$editora', '$paginas', '$valor', '$novo_nome')");
                    ?>

                    <script>
                    alert('Adicionado com Sucesso!');
                    <?php
                        echo "location.href='cad_livros.php'";
                    ?>
                    </script>
                <?php
     
                }

                if (isset($_GET['alterar'])) {
                
                    $codigo             = $_GET['codigo'];
                    $titulo             = $_GET['titulo'];
                    $codcategoria       = $_GET['codcategoria'];
                    $codclassificacao   = $_GET['codclassificacao'];
                    $ano                = $_GET['ano'];
                    $edicao             = $_GET['edicao'];
                    $codautor           = $_GET['codautor'];
                    $editora            = $_GET['editora'];
                    $paginas            = $_GET['paginas'];
                    $valor              = $_GET['valor'];
                    $fotocapa           = $_GET['fotocapa'];
                    
                    $sql      = "update livro set codigo,titulo,codcategoria,codclassificacao,ano,edicao,codautor,editora,paginas,valor,fotocapa = '$codigo','$titulo','$codcategoria','$codclassificacao','$ano','$edicao','$codautor','$editora','$paginas','$valor','$fotocapa'
                                 where codigo = '$codigo'";
                    $resultado = mysql_query($sql);
                    
                    ?>
                    <script>
                    alert('Alterado com Sucesso!');
                    <?php
                        echo "location.href='cad_livros.php'";
                    ?>
                    </script>
                <?php
                   
                }

                if (isset($_GET['excluir'])) {
            
                    $codigo             = $_GET['codigo'];
                    $titulo             = $_GET['titulo'];
                    $codcategoria       = $_GET['codcategoria'];
                    $codclassificacao   = $_GET['codclassificacao'];
                    $ano                = $_GET['ano'];
                    $edicao             = $_GET['edicao'];
                    $codautor           = $_GET['codautor'];
                    $editora            = $_GET['editora'];
                    $paginas            = $_GET['paginas'];
                    $valor              = $_GET['valor'];
                    $fotocapa           = $_GET['fotocapa'];
                    
                    $sql      = "delete * from livro 
                                 where codigo = '$codigo'";
                    $resultado = mysql_query($sql);
                    
                    ?>
                    <script>
                    alert('Excluido com Sucesso!');
                    <?php
                        echo "location.href='cad_livros.php'";
                    ?>
                    </script>
                <?php
                }


                $consulta = 'select * from livro';
                if((isset($_POST['pesquisar'])) or isset($_POST['gravar'])){

                    if($_POST['titulo'] != ''){
                        $consulta = $consulta." where titulo LIKE '%".$_POST['titulo']."%'";
                    }

                    $resultado = mysql_query($consulta);
                    echo $resultado;

                    while ($dados = mysql_fetch_array($resultado))
                    {
                            $strdados = $dados['codigo']."*".$dados['titulo'];
                        ?>
                        <tr>
                            <td><?php echo $dados['codigo']; ?></td>
                            <td><?php echo $dados['titulo']; ?></td>
                            <td><?php echo $dados['codcategoria']; ?></td>
                            <td><?php echo $dados['codclassificacao']; ?></td>
                            <td><?php echo $dados['ano']; ?></td>
                            <td><?php echo $dados['edicao']; ?></td>
                            <td><?php echo $dados['codautor']; ?></td>
                            <td><?php echo $dados['editora']; ?></td>
                            <td><?php echo $dados['paginas']; ?></td>
                            <td><?php echo $dados['valor']; ?></td>
                            <td><?php echo '<img src="fotos/'.$dados['fotocapa'].'" height="180" width="150" />'." "; ?></td>
                            <td>
                            
                                <?php      
                                echo"<a href='del_livro.php?codigo=".$dados['codigo']."'>
                                    <button type='button' name='excluir' id='excluir class='btn btn-danger'>Excluir</button>
                                </a>";               
                                ?>

                                <a href="#myModalAlterar"><button type='button' id='alterar' name='alterar' class='btn btn-primary' data-toggle='modal' data-target='#myModalAlterar' onclick='obterDadosModal("$strdados")'>Alterar</button></a>
                            </td>
                    </tr> 
                    
                    <?php 
                    }
                    mysql_close($conectar);
                }
                ?>
                </table>
            </div>
    </div>
    <!-- Biblioteca requerida -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>