<?php
//conectar com bando dados
$conectar = mysql_connect('localhost','root','');
$banco    = mysql_select_db('livraria');
?>

<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Home </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>



<!-- CABEÇALHO -->
<!-- ------------------------------------------------------ -->
<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo.png" width="230" height="130"></td>
    <td width=20%> </td>
    <td><center><a href="login.php"> <img src="Imagens/Login.png" width="40" height="40"> </a></center></td>
    </table>
</header>



<!-- PESQUISA -->
<!-- ------------------------------------------------------ -->
<form name="formulario" method="post" action="pesquisa.php">
<div class="pesquisa">
    <table border="0" width="90%" align="center"> 
        <tr>

            <td align="center"> 
                
                <select name="categoria">
                    <option value="" selected="selected"> Categoria </option>
                    <?php
                    $query = mysql_query("SELECT codigo, descricao FROM categoria");
                    
                    while($categoria = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $categoria['codigo']?>">
                                <?php echo $categoria['descricao']   ?></option>
                    <?php }
                    ?>
                </select>

                <select name="clasificacao">
                    <option value="" selected="selected"> Classificação </option>
                    <?php
                    $query = mysql_query("SELECT codigo, nome FROM classificacao");
                    
                    while($clasificacao = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $clasificacao['codigo']?>">
                                   <?php echo $clasificacao['nome']   ?></option>
                    <?php }
                    ?>
                </select>

                <input  type="submit" name="pesquisar" value="Pesquisar">

        </tr>
    </table>
</div>
</form>



<!-- PRODUTOS -->
<!-- ------------------------------------------------------ -->
<form name="formulario" method="POST" action="saibaMais.php" enctype="multipart/form-data">    
<div class="container">

    <div class="produtos">   
        <center>
            <img src="Imagens/foto1.png" width="190" height="300"><br><br>
            <?php 
            $sql = mysql_query("SELECT titulo, valor, fotocapa FROM livro WHERE codigo = 1");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo "".$dados->titulo."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->valor."<br><br>";            
                }
        ?>
        <input type="submit" name="produto1" value="Saiba Mais">
        </center>
    </div>

    <div class="produtos">   
        <center>
            <img src="Imagens/foto1.png" width="190" height="300"><br><br>
            <?php 
            $sql = mysql_query("SELECT titulo, valor, fotocapa FROM livro WHERE codigo = 1");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo "".$dados->titulo."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->valor."<br><br>";            
                }
        ?>
        <input type="submit" name="produto1" value="Saiba Mais">
        </center>
    </div>
    
    <div class="produtos">   
        <center>
            <img src="Imagens/foto1.png" width="190" height="300"><br><br>
            <?php 
            $sql = mysql_query("SELECT titulo, valor, fotocapa FROM livro WHERE codigo = 1");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo "".$dados->titulo."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->valor."<br><br>";            
                }
        ?>
        <input type="submit" name="produto1" value="Saiba Mais">
        </center>
    </div>
</div>
</form>



<!-- RODAPÉ -->
<!-- ------------------------------------------------------ -->
<div class="footer">
    <table border="0" width="100%">
    <tr>
    <td><center><img src="Imagens/Logo.png" width="220" height="123"></center></td>
    </tr> 
</div>
</body>
</HTML>