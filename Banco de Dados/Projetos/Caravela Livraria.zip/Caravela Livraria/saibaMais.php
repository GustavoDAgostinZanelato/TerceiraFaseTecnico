<?php
//conectar com bando dados
$conectar = mysql_connect('localhost','root','');
$banco    = mysql_select_db('livraria');
?>

<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Página Botão Saiba Mais </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>



<!-- CABEÇALHO -->
<!-- ------------------------------------------------------ -->
<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo.png" width="230" height="130"></td>
    <td width=20%> </td>
    </table>
</header>



<!-- PESQUISAS -->
<!-- ------------------------------------------------------ -->
<div class="box_login">
    <table border="0" width="90%" align="center">
      <tr>
        <td>


            <!-- PESQUISA 1 -->
            <table border="0" width="90%" align="center">
              <tr>
                <td>
                  <center>
                  <img src="Imagens/foto1.png" width="190" height="300"><br><br>
                    <?php
                        if (isset($_POST['produto1']))
                        {
                            //Seleciona todas as informacoes da tabela
                            $sql = mysql_query("SELECT codigo, titulo, codcategoria,codclassificacao,ano,edicao,codautor,editora,paginas,valor,fotocapa 
                                                FROM livro WHERE codigo = 1");
                            
                            while ($dados = mysql_fetch_object($sql))
                                  {

                                        
                                
                        ?>
                  </center>
                  </td>
                  <td>
                    <?php
                                echo "Codigo: ".$dados->codigo."<br>";
                                echo "Titulo: ".$dados->titulo."<br>";
                                echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                echo "Ano: ".$dados->ano."<br>";
                                echo "Edição: ".$dados->edicao."<br>";
                                echo "Cod Autor: ".$dados->codautor."<br>";
                                echo "Editora: ".$dados->editora."<br>";
                                echo "Páginas: ".$dados->paginas."<br>";
                                echo "Valor: ".$dados->valor."<br>"; 
                            }
                        }
                    ?>
                  </td>
              </tr>
            </table>


            <!-- PESQUISA 2 -->
            <table border="0" width="90%" align="center">
              <tr>
                <td>
                  <center>
                    <?php
                        if (isset($_POST['produto2']))
                        {
                            //Seleciona todas as informacoes da tabela
                            $sql = mysql_query("SELECT codigo, titulo, codcategoria,codclassificacao,ano,edicao,codautor,editora,paginas,valor,fotocapa 
                                                FROM livro WHERE codigo = 2");
                            
                            while ($dados = mysql_fetch_object($sql))
                                  {

                                        
                                
                        ?>
                  </center>
                  </td>
                  <td>
                    <?php
                                echo "Codigo: ".$dados->codigo."<br>";
                                echo "Titulo: ".$dados->titulo."<br>";
                                echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                echo "Ano: ".$dados->ano."<br>";
                                echo "Edição: ".$dados->edicao."<br>";
                                echo "Cod Autor: ".$dados->codautor."<br>";
                                echo "Editora: ".$dados->editora."<br>";
                                echo "Páginas: ".$dados->paginas."<br>";
                                echo "Valor: ".$dados->valor."<br>"; 
                            }
                        }
                    ?>
                  </td>
              </tr>
            </table>
            

            <!-- PESQUISA 3 -->
            <table border="0" width="90%" align="center">
              <tr>
                <td>
                  <center>
                    <?php
                        if (isset($_POST['produto3']))
                        {
                            //Seleciona todas as informacoes da tabela
                            $sql = mysql_query("SELECT codigo, titulo, codcategoria,codclassificacao,ano,edicao,codautor,editora,paginas,valor,fotocapa 
                                                FROM livro WHERE codigo = 3");
                            
                            while ($dados = mysql_fetch_object($sql))
                                  {

                                        
                                
                        ?>
                  </center>
                  </td>
                  <td>
                    <?php
                                echo "Codigo: ".$dados->codigo."<br>";
                                echo "Titulo: ".$dados->titulo."<br>";
                                echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                echo "Ano: ".$dados->ano."<br>";
                                echo "Edição: ".$dados->edicao."<br>";
                                echo "Cod Autor: ".$dados->codautor."<br>";
                                echo "Editora: ".$dados->editora."<br>";
                                echo "Páginas: ".$dados->paginas."<br>";
                                echo "Valor: ".$dados->valor."<br>"; 
                            }
                        }
                    ?>
                  </td>
              </tr>
            </table>
            
        
</div>
</body>
</html>