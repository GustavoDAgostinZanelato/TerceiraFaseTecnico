<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Login Usuários </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>


<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo2.png" width="230" height="130"></td>
    <td width=20%> </td>
    </table>
</header>


<div class="box_login">
    <table border="0" width="50%" align="center">

    <tr>
        <td align="center">
            <center><h3> Login do Usuário </h3></center>
            <center><h2>Bem-Vindo(a)</h2></center>
            <br><br>
  
         
            <form name="formulario" method="post" action="login.php">
            <label>Login:</label>
            <input type="text" name="login" id="login" size="20" required><br><br>
            <label>Senha:</label>
            <input type="password" name="senha" id="senha" size="20" required><br><br>
            <input type="submit" value="Conectar" id="conectar" name="conectar"><br><br>
            </form>

            <?php
            // Conectar com banco de dados
            $conexao = mysqli_connect('localhost', 'root', '', 'loja');

            if (!$conexao) {
                die('Erro ao conectar ao banco de dados: ' . mysqli_connect_error());
            }

            if (isset($_POST['conectar'])) {
                $login = $_POST['login'];
                $senha = $_POST['senha'];

                // Preparar a consulta usando prepared statements
                $consulta = mysqli_prepare($conexao, "SELECT * FROM usuario WHERE login = ? AND senha = ?");
                mysqli_stmt_bind_param($consulta, 'ss', $login, $senha);
                mysqli_stmt_execute($consulta);
                mysqli_stmt_store_result($consulta);
                $resultado = mysqli_stmt_num_rows($consulta);

                if ($resultado == 0) {
                    echo "<h4>Login ou senha invalidos</h4>";
                } else {
                    // Iniciar a sessão e redirecionar para a página de menu
                    session_start();
                    $_SESSION['login'] = $login;
                    header("location: menu.html");
                    exit; // Terminar a execução após o redirecionamento
                }
            }
            ?>
            
        </td>
    </tr>  

    </table>
</div>

</body>
</html>
