<?php

//Inicia e sess�o
session_start();

//Conecta com o banco de dados (localweb, usuario, senha)
$conectar = mysql_connect('localhost','root','');

//Escolhe qual banco de dados usar
$banco = mysql_select_db('loja');
?>


<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Resultado Pesquisar </title>
    <link rel="stylesheet" href="stylesCadastros.css" type="text/css">
</head>
<body>


<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo2.png" width="230" height="130"></td>
    </table>
</header>


<?php

//Verifica qual bot�o foi selecionado (gravar, excluir, alterar ou pesquisar)
if (isset($_POST['gravar']))
{
   $codigo = $_POST['codigo'];
   $descricao = $_POST['descricao'];

   //Criar o comando Gravar (INSERT) no banco de dados
   $sql = "INSERT INTO categoria(codigo,descricao) VALUES ('$codigo', '$descricao')";

   //Executar o comando SQL no BD
   $resultado = mysql_query($sql);

   //Verificar se gravou com sucesso no Banco de Dados

   if($resultado === TRUE)
   {
    echo 'Cadastro realizado com sucesso';
   }
   else
   {
    echo'Erro ao gravar dados';
   }
}


if (isset($_POST['excluir']))
{
   $codigo = $_POST['codigo'];
   $descricao   = $_POST['descricao'];

   //Criar o comando Gravar (DELETE) no banco de dados
   $sql = "DELETE FROM categoria WHERE codigo = '$codigo'";
        
   //Executar o comando SQL no BD
   $resultado = mysql_query($sql);
   
   //Verificar e excluiu com sucesso no BD
   if ($resultado === TRUE)
   {
    echo 'Exclusao realizada com sucesso';
   }
   else
   {
    echo 'Erro ao excluir dados';
   }
}


if (isset($_POST['alterar']))
{
   $codigo = $_POST['codigo'];
   $descricao = $_POST['descricao'];
   
   //Criar o comando Alterar(UPDATE) no Banco de Dados
   $sql = "UPDATE categoria SET descricao='$descricao'
        WHERE codigo = '$codigo'";
        
   //Executar o comando SQL no BD
   $resultado = mysql_query($sql);
   
   //Verificar se alterou com sucesso o BD
   if ($resultado === TRUE)
   {
    echo 'Dados alterados com sucesso';
   }
   else
   {
    echo 'Erro ao alterar dados';
   }
}

?>

<div class="box_cadastros">
    <table border="0" width="90%" align="center">
      <tr>
        <td>
            <center>
            <?php
            $codigo = $_POST['codigo'];
            if (isset($_POST['pesquisar']))
            {
            //Seleciona todas as informa��es da tabela
            $sql = mysql_query("SELECT codigo,descricao FROM categoria WHERE codigo = '$codigo'");
            
            echo "<h3>Categorias Cadastradas</h3><br>";
            while ($dados = mysql_fetch_object($sql))
            {
                           echo "Codigo: ".$dados->codigo." ";
                           echo "Descricao: ".$dados->descricao."<br>";
            }
            }

            ?>
            </center>
         </td>
      </tr>
   </table>
</div>
