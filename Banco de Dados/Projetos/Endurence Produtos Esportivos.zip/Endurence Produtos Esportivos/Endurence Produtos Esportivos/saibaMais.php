<?php
//Inicia e sess�o
session_start();

//Conecta com o banco de dados (localweb, usuario, senha)
$conectar = mysql_connect('localhost','root','');

//Escolhe qual banco de dados usar
$banco = mysql_select_db('loja');
?>

<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Página Botão Saiba Mais </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>


<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo2.png" width="230" height="130"></td>
    <td width=20%> </td>
    </table>
</header>



<div class="box_login">
    <table border="0" width="90%" align="center">
      <tr>
        <td>
            <table border="0" width="90%" align="center">
              <tr>
                <td>
                  <center>
                      <?php
                        if (isset($_POST['produto1']))
                        {
                          //Seleciona todas as informa��es da tabela
                          $sql = mysql_query("SELECT codigo, descricao, codcategoria,codclassificacao,codesporte,codmarca,cor,tamanho,preco,foto 
                                              FROM produto WHERE codigo = 1");
                          
                          while ($dados = mysql_fetch_object($sql))
                          {
                                        echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="200" width="200" />'."<br><br>"; 
                        ?>
                  </center>
                  </td>
                  <td>
                  <?php
                                        echo "Codigo: ".$dados->codigo."<br>";
                                        echo "Descricao: ".$dados->descricao."<br>";
                                        echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                        echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                        echo "Cod Esporte: ".$dados->codesporte."<br>";
                                        echo "Cod Marca: ".$dados->codmarca."<br>";
                                        echo "Cor: ".$dados->cor."<br>";
                                        echo "Tamanho: ".$dados->tamanho."<br>";
                                        echo "Preco: ".$dados->preco."<br><br>";
                                        
                            }
                          } 
                    ?>
                  </td>
              </tr>
            </table>
                 
            <table border="0" width="90%" align="center">
              <tr>
                <td>
                    <table border="0" width="90%" align="center">
                      <tr>
                        <td>
                          <center>
                              <?php
                                if (isset($_POST['produto3']))
                                {
                                  //Seleciona todas as informa��es da tabela
                                  $sql = mysql_query("SELECT codigo, descricao, codcategoria,codclassificacao,codesporte,codmarca,cor,tamanho,preco,foto 
                                                      FROM produto WHERE codigo = 3");
                                  
                                  while ($dados = mysql_fetch_object($sql))
                                  {
                                                echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="200" width="200" />'."<br><br>"; 
                                ?>
                          </center>
                          </td>
                          <td>
                          <?php
                                                echo "Codigo: ".$dados->codigo."<br>";
                                                echo "Descricao: ".$dados->descricao."<br>";
                                                echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                                echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                                echo "Cod Esporte: ".$dados->codesporte."<br>";
                                                echo "Cod Marca: ".$dados->codmarca."<br>";
                                                echo "Cor: ".$dados->cor."<br>";
                                                echo "Tamanho: ".$dados->tamanho."<br>";
                                                echo "Preco: ".$dados->preco."<br><br>";
                                                
                                    }
                                  } 
                            ?>
                  </td>
                </tr>
            </table>

            <table border="0" width="90%" align="center">
              <tr>
                <td>
                    <table border="0" width="90%" align="center">
                      <tr>
                        <td>
                          <center>
                              <?php
                                if (isset($_POST['produto2']))
                                {
                                  //Seleciona todas as informa��es da tabela
                                  $sql = mysql_query("SELECT codigo, descricao, codcategoria,codclassificacao,codesporte,codmarca,cor,tamanho,preco,foto 
                                                      FROM produto WHERE codigo = 2");
                                  
                                  while ($dados = mysql_fetch_object($sql))
                                  {
                                                echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="200" width="200" />'."<br><br>"; 
                                ?>
                          </center>
                          </td>
                          <td>
                          <?php
                                                echo "Codigo: ".$dados->codigo."<br>";
                                                echo "Descricao: ".$dados->descricao."<br>";
                                                echo "Cod Categoria: ".$dados->codcategoria."<br>";
                                                echo "Cod Classificacao: ".$dados->codclassificacao."<br>";
                                                echo "Cod Esporte: ".$dados->codesporte."<br>";
                                                echo "Cod Marca: ".$dados->codmarca."<br>";
                                                echo "Cor: ".$dados->cor."<br>";
                                                echo "Tamanho: ".$dados->tamanho."<br>";
                                                echo "Preco: ".$dados->preco."<br><br>";
                                                
                                    }
                                  } 
                            ?>
                  </td>
                </tr>
            </table>
        </td>
    </tr>
  </table>
</div>
</body>
</html>