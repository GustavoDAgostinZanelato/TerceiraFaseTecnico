<?php
//conectar com bando dados
$conectar = mysql_connect('localhost','root','');
$banco    = mysql_select_db('loja');
?>

<html lang="pt-BR" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Home </title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>


<header>
    <table border="0" width="95%" align="center">
    <td height="120"><img src="Imagens/Logo2.png" width="230" height="130"></td>
    <td width=20%> </td>
    <td><center><a href="login.php"> <img src="Imagens/Login.png" width="40" height="40"> </a></center></td>
    </table>
</header>


<form name="formulario" method="post" action="pesquisa.php">
<div class="pesquisa">
    <table border="0" width="90%" align="center"> 
        <tr>

            <td align="center"> 
                
                <select name="categoria">
                    <option value="" selected="selected"> Categoria </option>
                    <?php
                    $query = mysql_query("SELECT codigo, descricao FROM categoria");
                    
                    while($categoria = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $categoria['codigo']?>">
                                <?php echo $categoria['descricao']   ?></option>
                    <?php }
                    ?>
                </select>

                <select name="clasificacao">
                    <option value="" selected="selected"> Classificação </option>
                    <?php
                    $query = mysql_query("SELECT codigo, nome FROM clasificacao");
                    
                    while($clasificacao = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $clasificacao['codigo']?>">
                                   <?php echo $clasificacao['nome']   ?></option>
                    <?php }
                    ?>
                </select>

                <select name="esporte">
                    <option value="" selected="selected"> Esporte </option>
                    <?php
                    $query = mysql_query("SELECT codigo, nome FROM esporte");
                    
                    while($esporte = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $esporte['codigo']?>">
                                   <?php echo $esporte['nome']   ?></option>
                    <?php }
                    ?>
                </select>

                <select name="marca">
                    <option value="" selected="selected"> Marca </option>
                    <?php
                    $query = mysql_query("SELECT codigo, nome FROM marca");
                    
                    while($marca = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $marca['codigo']?>">
                                   <?php echo $marca['nome']   ?></option>
                    <?php }
                    ?>
                </select>

                <select name="produto">
                    <option value="" selected="selected"> Valor </option>
                    <?php
                    $query = mysql_query("SELECT codigo, preco FROM produto");
                    
                    while($produto = mysql_fetch_array($query))
                    {?>
                    <option value="<?php echo $produto['codigo']?>">
                                   <?php echo $produto['preco']   ?></option>
                    <?php }
                    ?>
                </select>
                <input  type="submit" name="pesquisar" value="Pesquisar">

        </tr>
    </table>
</div>


</form>








</form>



<form name="formulario" method="POST" action="saibaMais.php" enctype="multipart/form-data">    
<div class="container">

    <div class="produtos">   
        <center>
            <?php 
            $sql = mysql_query("SELECT descricao, preco, foto FROM produto WHERE codigo = 1");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="300" width="300" />'."<br><br>"; 
                    echo "".$dados->descricao."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->preco."<br><br>";            
                }
        ?>
        <input type="submit" name="produto1" value="Saiba Mais">
        </center>
    </div>

    <div class="produtos">   
        <center>
        <?php 
            $sql = mysql_query("SELECT descricao, preco, foto FROM produto WHERE codigo = 2");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="300" width="300" />'."<br><br>"; 
                    echo "".$dados->descricao."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->preco."<br><br>";            
                }
        ?>
        <input type="submit" name="produto2" value="Saiba Mais">
        </center>
    </div>
    
    <div class="produtos">   
        <center>
        <?php 
            $sql = mysql_query("SELECT descricao, preco, foto FROM produto WHERE codigo = 3");
                while ($dados = mysql_fetch_object($sql))
                {
                    echo '<img src="Cadastros/Imagens/'.$dados->foto.'" height="300" width="300" />'."<br><br>"; 
                    echo "".$dados->descricao."<br><br>";
                    echo "<h2>A partir de:</h2>".$dados->preco."<br><br>";            
                }
        ?>
        <input type="submit" name="produto3" value="Saiba Mais"><br><br>
        </center>
    </div>
</div>
</form>

<div class="footer">
    <table border="0" width="100%">
    <tr>
    <td><center><img src="Imagens/Logo2.png" width="220" height="123"></center></td>
    </tr> 
</div>

</body>
</HTML>